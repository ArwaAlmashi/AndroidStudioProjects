package com.example.arwa

class TextItem (var text: String, var amount: Double)